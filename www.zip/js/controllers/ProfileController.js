craftEd.controller('ProfileController', ['$scope', '$http', '$location', '$ionicPopup', '$window',function($scope, $http, $location, $window, $ionicPopup){
// $scope.reload();
$scope.$on("$ionicView.afterEnter", function(event, data){
  console.log("hello")
})


}]);
